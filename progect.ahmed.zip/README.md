-landing page
The page displays a set of sections ,

-header : Contains a menu that in turn facilitates the use of the site ,

-main : contains element main On the group of sections on the page ,

-section : When creating this item, it appears dynamically in the list above ,
We also see when we stand on one of the sections on the page, a selection for the section we are standing on

- Project Objective: This project was carried out in implementation of one of the tests of the Udasty platform